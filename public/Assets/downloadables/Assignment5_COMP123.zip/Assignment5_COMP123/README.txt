-----README-----

There are:
22 Lables which include the titles and courses and to output grade points and GPA
8 numeric up and downs - for each hours in courses
8 combo boxes - for each course to input the grade
1 button - calculate button to calculate all the grade points and grade average

I have used 2 classes which are in the same file
 1 to do all of the calculations
 1 to get the selected value from combo box and return a double value for each grade

