﻿namespace GUI_Assignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.C1Grade = new System.Windows.Forms.ComboBox();
            this.C2Grade = new System.Windows.Forms.ComboBox();
            this.C3Grade = new System.Windows.Forms.ComboBox();
            this.C4Grade = new System.Windows.Forms.ComboBox();
            this.C5Grade = new System.Windows.Forms.ComboBox();
            this.C6Grade = new System.Windows.Forms.ComboBox();
            this.C7Grade = new System.Windows.Forms.ComboBox();
            this.C8Grade = new System.Windows.Forms.ComboBox();
            this.btnCal = new System.Windows.Forms.Button();
            this.C1CreditHours = new System.Windows.Forms.NumericUpDown();
            this.C2CreditHours = new System.Windows.Forms.NumericUpDown();
            this.C3CreditHours = new System.Windows.Forms.NumericUpDown();
            this.C4CreditHours = new System.Windows.Forms.NumericUpDown();
            this.C5CreditHours = new System.Windows.Forms.NumericUpDown();
            this.C6CreditHours = new System.Windows.Forms.NumericUpDown();
            this.C7CreditHours = new System.Windows.Forms.NumericUpDown();
            this.C8CreditHours = new System.Windows.Forms.NumericUpDown();
            this.GPAValue = new System.Windows.Forms.Label();
            this.GPAlbl = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.C8GradePoint = new System.Windows.Forms.Label();
            this.C6GradePoint = new System.Windows.Forms.Label();
            this.C7GradePoint = new System.Windows.Forms.Label();
            this.C5GradePoint = new System.Windows.Forms.Label();
            this.C4GradePoint = new System.Windows.Forms.Label();
            this.C3GradePoint = new System.Windows.Forms.Label();
            this.C1GradePoint = new System.Windows.Forms.Label();
            this.C2GradePoint = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.C1CreditHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C2CreditHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3CreditHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C4CreditHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C5CreditHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6CreditHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C7CreditHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8CreditHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // C1Grade
            // 
            this.C1Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C1Grade.FormattingEnabled = true;
            this.C1Grade.Items.AddRange(new object[] {
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "C-",
            "D+",
            "D",
            "D-"});
            this.C1Grade.Location = new System.Drawing.Point(316, 97);
            this.C1Grade.Name = "C1Grade";
            this.C1Grade.Size = new System.Drawing.Size(50, 21);
            this.C1Grade.TabIndex = 0;
            // 
            // C2Grade
            // 
            this.C2Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C2Grade.FormattingEnabled = true;
            this.C2Grade.Items.AddRange(new object[] {
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "C-",
            "D+",
            "D",
            "D-"});
            this.C2Grade.Location = new System.Drawing.Point(316, 137);
            this.C2Grade.Name = "C2Grade";
            this.C2Grade.Size = new System.Drawing.Size(50, 21);
            this.C2Grade.TabIndex = 10;
            // 
            // C3Grade
            // 
            this.C3Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C3Grade.FormattingEnabled = true;
            this.C3Grade.Items.AddRange(new object[] {
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "C-",
            "D+",
            "D",
            "D-"});
            this.C3Grade.Location = new System.Drawing.Point(316, 176);
            this.C3Grade.Name = "C3Grade";
            this.C3Grade.Size = new System.Drawing.Size(50, 21);
            this.C3Grade.TabIndex = 11;
            // 
            // C4Grade
            // 
            this.C4Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C4Grade.FormattingEnabled = true;
            this.C4Grade.Items.AddRange(new object[] {
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "C-",
            "D+",
            "D",
            "D-"});
            this.C4Grade.Location = new System.Drawing.Point(316, 217);
            this.C4Grade.Name = "C4Grade";
            this.C4Grade.Size = new System.Drawing.Size(50, 21);
            this.C4Grade.TabIndex = 12;
            // 
            // C5Grade
            // 
            this.C5Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C5Grade.FormattingEnabled = true;
            this.C5Grade.Items.AddRange(new object[] {
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "C-",
            "D+",
            "D",
            "D-"});
            this.C5Grade.Location = new System.Drawing.Point(316, 257);
            this.C5Grade.Name = "C5Grade";
            this.C5Grade.Size = new System.Drawing.Size(50, 21);
            this.C5Grade.TabIndex = 13;
            // 
            // C6Grade
            // 
            this.C6Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C6Grade.FormattingEnabled = true;
            this.C6Grade.Items.AddRange(new object[] {
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "C-",
            "D+",
            "D",
            "D-"});
            this.C6Grade.Location = new System.Drawing.Point(316, 299);
            this.C6Grade.Name = "C6Grade";
            this.C6Grade.Size = new System.Drawing.Size(50, 21);
            this.C6Grade.TabIndex = 14;
            // 
            // C7Grade
            // 
            this.C7Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C7Grade.FormattingEnabled = true;
            this.C7Grade.Items.AddRange(new object[] {
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "C-",
            "D+",
            "D",
            "D-"});
            this.C7Grade.Location = new System.Drawing.Point(316, 339);
            this.C7Grade.Name = "C7Grade";
            this.C7Grade.Size = new System.Drawing.Size(50, 21);
            this.C7Grade.TabIndex = 15;
            // 
            // C8Grade
            // 
            this.C8Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C8Grade.FormattingEnabled = true;
            this.C8Grade.Items.AddRange(new object[] {
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "C-",
            "D+",
            "D",
            "D-"});
            this.C8Grade.Location = new System.Drawing.Point(316, 378);
            this.C8Grade.Name = "C8Grade";
            this.C8Grade.Size = new System.Drawing.Size(50, 21);
            this.C8Grade.TabIndex = 16;
            // 
            // btnCal
            // 
            this.btnCal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCal.Location = new System.Drawing.Point(371, 427);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(121, 48);
            this.btnCal.TabIndex = 37;
            this.btnCal.Text = "Calculate";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // C1CreditHours
            // 
            this.C1CreditHours.Location = new System.Drawing.Point(191, 98);
            this.C1CreditHours.Name = "C1CreditHours";
            this.C1CreditHours.Size = new System.Drawing.Size(94, 20);
            this.C1CreditHours.TabIndex = 38;
            // 
            // C2CreditHours
            // 
            this.C2CreditHours.Location = new System.Drawing.Point(191, 138);
            this.C2CreditHours.Name = "C2CreditHours";
            this.C2CreditHours.Size = new System.Drawing.Size(94, 20);
            this.C2CreditHours.TabIndex = 39;
            // 
            // C3CreditHours
            // 
            this.C3CreditHours.Location = new System.Drawing.Point(191, 177);
            this.C3CreditHours.Name = "C3CreditHours";
            this.C3CreditHours.Size = new System.Drawing.Size(94, 20);
            this.C3CreditHours.TabIndex = 40;
            // 
            // C4CreditHours
            // 
            this.C4CreditHours.Location = new System.Drawing.Point(191, 218);
            this.C4CreditHours.Name = "C4CreditHours";
            this.C4CreditHours.Size = new System.Drawing.Size(94, 20);
            this.C4CreditHours.TabIndex = 41;
            // 
            // C5CreditHours
            // 
            this.C5CreditHours.Location = new System.Drawing.Point(191, 258);
            this.C5CreditHours.Name = "C5CreditHours";
            this.C5CreditHours.Size = new System.Drawing.Size(94, 20);
            this.C5CreditHours.TabIndex = 42;
            // 
            // C6CreditHours
            // 
            this.C6CreditHours.Location = new System.Drawing.Point(191, 300);
            this.C6CreditHours.Name = "C6CreditHours";
            this.C6CreditHours.Size = new System.Drawing.Size(94, 20);
            this.C6CreditHours.TabIndex = 43;
            // 
            // C7CreditHours
            // 
            this.C7CreditHours.Location = new System.Drawing.Point(191, 340);
            this.C7CreditHours.Name = "C7CreditHours";
            this.C7CreditHours.Size = new System.Drawing.Size(94, 20);
            this.C7CreditHours.TabIndex = 44;
            // 
            // C8CreditHours
            // 
            this.C8CreditHours.Location = new System.Drawing.Point(191, 379);
            this.C8CreditHours.Name = "C8CreditHours";
            this.C8CreditHours.Size = new System.Drawing.Size(94, 20);
            this.C8CreditHours.TabIndex = 45;
            // 
            // GPAValue
            // 
            this.GPAValue.AutoSize = true;
            this.GPAValue.BackColor = System.Drawing.Color.White;
            this.GPAValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GPAValue.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.GPAValue.Image = global::GUI_Assignment.Properties.Resources._23687c6419eb0d5af218285cc064ea3b;
            this.GPAValue.Location = new System.Drawing.Point(268, 444);
            this.GPAValue.MaximumSize = new System.Drawing.Size(100, 100);
            this.GPAValue.Name = "GPAValue";
            this.GPAValue.Size = new System.Drawing.Size(12, 17);
            this.GPAValue.TabIndex = 47;
            this.GPAValue.Text = " ";
            this.GPAValue.Visible = false;
            // 
            // GPAlbl
            // 
            this.GPAlbl.AutoSize = true;
            this.GPAlbl.BackColor = System.Drawing.Color.Transparent;
            this.GPAlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GPAlbl.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.GPAlbl.Image = ((System.Drawing.Image)(resources.GetObject("GPAlbl.Image")));
            this.GPAlbl.Location = new System.Drawing.Point(55, 438);
            this.GPAlbl.Name = "GPAlbl";
            this.GPAlbl.Size = new System.Drawing.Size(190, 24);
            this.GPAlbl.TabIndex = 46;
            this.GPAlbl.Text = "Grade Point Average:";
            this.GPAlbl.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label12.Image = ((System.Drawing.Image)(resources.GetObject("label12.Image")));
            this.label12.Location = new System.Drawing.Point(390, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(102, 20);
            this.label12.TabIndex = 36;
            this.label12.Text = "Grade Points";
            // 
            // C8GradePoint
            // 
            this.C8GradePoint.AutoSize = true;
            this.C8GradePoint.BackColor = System.Drawing.Color.White;
            this.C8GradePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C8GradePoint.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.C8GradePoint.Image = ((System.Drawing.Image)(resources.GetObject("C8GradePoint.Image")));
            this.C8GradePoint.Location = new System.Drawing.Point(431, 379);
            this.C8GradePoint.MaximumSize = new System.Drawing.Size(100, 100);
            this.C8GradePoint.Name = "C8GradePoint";
            this.C8GradePoint.Size = new System.Drawing.Size(12, 17);
            this.C8GradePoint.TabIndex = 35;
            this.C8GradePoint.Text = " ";
            this.C8GradePoint.Visible = false;
            // 
            // C6GradePoint
            // 
            this.C6GradePoint.AutoSize = true;
            this.C6GradePoint.BackColor = System.Drawing.Color.White;
            this.C6GradePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C6GradePoint.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.C6GradePoint.Image = ((System.Drawing.Image)(resources.GetObject("C6GradePoint.Image")));
            this.C6GradePoint.Location = new System.Drawing.Point(431, 300);
            this.C6GradePoint.MaximumSize = new System.Drawing.Size(100, 100);
            this.C6GradePoint.Name = "C6GradePoint";
            this.C6GradePoint.Size = new System.Drawing.Size(12, 17);
            this.C6GradePoint.TabIndex = 34;
            this.C6GradePoint.Text = " ";
            this.C6GradePoint.Visible = false;
            // 
            // C7GradePoint
            // 
            this.C7GradePoint.AutoSize = true;
            this.C7GradePoint.BackColor = System.Drawing.Color.White;
            this.C7GradePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C7GradePoint.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.C7GradePoint.Image = ((System.Drawing.Image)(resources.GetObject("C7GradePoint.Image")));
            this.C7GradePoint.Location = new System.Drawing.Point(431, 340);
            this.C7GradePoint.MaximumSize = new System.Drawing.Size(100, 100);
            this.C7GradePoint.Name = "C7GradePoint";
            this.C7GradePoint.Size = new System.Drawing.Size(12, 17);
            this.C7GradePoint.TabIndex = 33;
            this.C7GradePoint.Text = " ";
            this.C7GradePoint.Visible = false;
            // 
            // C5GradePoint
            // 
            this.C5GradePoint.AutoSize = true;
            this.C5GradePoint.BackColor = System.Drawing.Color.White;
            this.C5GradePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C5GradePoint.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.C5GradePoint.Image = ((System.Drawing.Image)(resources.GetObject("C5GradePoint.Image")));
            this.C5GradePoint.Location = new System.Drawing.Point(431, 258);
            this.C5GradePoint.MaximumSize = new System.Drawing.Size(100, 100);
            this.C5GradePoint.Name = "C5GradePoint";
            this.C5GradePoint.Size = new System.Drawing.Size(12, 17);
            this.C5GradePoint.TabIndex = 32;
            this.C5GradePoint.Text = " ";
            this.C5GradePoint.Visible = false;
            // 
            // C4GradePoint
            // 
            this.C4GradePoint.AutoSize = true;
            this.C4GradePoint.BackColor = System.Drawing.Color.White;
            this.C4GradePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C4GradePoint.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.C4GradePoint.Image = ((System.Drawing.Image)(resources.GetObject("C4GradePoint.Image")));
            this.C4GradePoint.Location = new System.Drawing.Point(431, 218);
            this.C4GradePoint.MaximumSize = new System.Drawing.Size(100, 100);
            this.C4GradePoint.Name = "C4GradePoint";
            this.C4GradePoint.Size = new System.Drawing.Size(12, 17);
            this.C4GradePoint.TabIndex = 31;
            this.C4GradePoint.Text = " ";
            this.C4GradePoint.Visible = false;
            // 
            // C3GradePoint
            // 
            this.C3GradePoint.AutoSize = true;
            this.C3GradePoint.BackColor = System.Drawing.Color.White;
            this.C3GradePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3GradePoint.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.C3GradePoint.Image = ((System.Drawing.Image)(resources.GetObject("C3GradePoint.Image")));
            this.C3GradePoint.Location = new System.Drawing.Point(431, 177);
            this.C3GradePoint.MaximumSize = new System.Drawing.Size(100, 100);
            this.C3GradePoint.Name = "C3GradePoint";
            this.C3GradePoint.Size = new System.Drawing.Size(12, 17);
            this.C3GradePoint.TabIndex = 30;
            this.C3GradePoint.Text = " ";
            this.C3GradePoint.Visible = false;
            // 
            // C1GradePoint
            // 
            this.C1GradePoint.AutoSize = true;
            this.C1GradePoint.BackColor = System.Drawing.Color.White;
            this.C1GradePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1GradePoint.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.C1GradePoint.Image = ((System.Drawing.Image)(resources.GetObject("C1GradePoint.Image")));
            this.C1GradePoint.Location = new System.Drawing.Point(431, 98);
            this.C1GradePoint.MaximumSize = new System.Drawing.Size(100, 100);
            this.C1GradePoint.Name = "C1GradePoint";
            this.C1GradePoint.Size = new System.Drawing.Size(12, 17);
            this.C1GradePoint.TabIndex = 29;
            this.C1GradePoint.Text = " ";
            this.C1GradePoint.Visible = false;
            // 
            // C2GradePoint
            // 
            this.C2GradePoint.AutoSize = true;
            this.C2GradePoint.BackColor = System.Drawing.Color.White;
            this.C2GradePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2GradePoint.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.C2GradePoint.Image = ((System.Drawing.Image)(resources.GetObject("C2GradePoint.Image")));
            this.C2GradePoint.Location = new System.Drawing.Point(431, 138);
            this.C2GradePoint.MaximumSize = new System.Drawing.Size(100, 100);
            this.C2GradePoint.Name = "C2GradePoint";
            this.C2GradePoint.Size = new System.Drawing.Size(12, 17);
            this.C2GradePoint.TabIndex = 28;
            this.C2GradePoint.Text = " ";
            this.C2GradePoint.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label11.Image = ((System.Drawing.Image)(resources.GetObject("label11.Image")));
            this.label11.Location = new System.Drawing.Point(312, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 20);
            this.label11.TabIndex = 26;
            this.label11.Text = "Grade";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label10.Image = ((System.Drawing.Image)(resources.GetObject("label10.Image")));
            this.label10.Location = new System.Drawing.Point(187, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 20);
            this.label10.TabIndex = 17;
            this.label10.Text = "Credit Hours";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label9.Image = global::GUI_Assignment.Properties.Resources._23687c6419eb0d5af218285cc064ea3b;
            this.label9.Location = new System.Drawing.Point(75, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 20);
            this.label9.TabIndex = 9;
            this.label9.Text = "COURSES";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label8.Image = ((System.Drawing.Image)(resources.GetObject("label8.Image")));
            this.label8.Location = new System.Drawing.Point(88, 379);
            this.label8.MaximumSize = new System.Drawing.Size(100, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 17);
            this.label8.TabIndex = 8;
            this.label8.Text = "Course 8";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label7.Image = ((System.Drawing.Image)(resources.GetObject("label7.Image")));
            this.label7.Location = new System.Drawing.Point(88, 340);
            this.label7.MaximumSize = new System.Drawing.Size(100, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Course 7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
            this.label6.Location = new System.Drawing.Point(88, 300);
            this.label6.MaximumSize = new System.Drawing.Size(100, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Course 6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
            this.label5.Location = new System.Drawing.Point(88, 258);
            this.label5.MaximumSize = new System.Drawing.Size(100, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Course 5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(88, 218);
            this.label4.MaximumSize = new System.Drawing.Size(100, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Course 4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(88, 177);
            this.label3.MaximumSize = new System.Drawing.Size(100, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Course 3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(88, 138);
            this.label2.MaximumSize = new System.Drawing.Size(100, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Course 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(88, 101);
            this.label1.MaximumSize = new System.Drawing.Size(100, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Course 1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GUI_Assignment.Properties.Resources._23687c6419eb0d5af218285cc064ea3b;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(555, 494);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(553, 483);
            this.Controls.Add(this.GPAValue);
            this.Controls.Add(this.GPAlbl);
            this.Controls.Add(this.C8CreditHours);
            this.Controls.Add(this.C7CreditHours);
            this.Controls.Add(this.C6CreditHours);
            this.Controls.Add(this.C5CreditHours);
            this.Controls.Add(this.C4CreditHours);
            this.Controls.Add(this.C3CreditHours);
            this.Controls.Add(this.C2CreditHours);
            this.Controls.Add(this.C1CreditHours);
            this.Controls.Add(this.btnCal);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.C8GradePoint);
            this.Controls.Add(this.C6GradePoint);
            this.Controls.Add(this.C7GradePoint);
            this.Controls.Add(this.C5GradePoint);
            this.Controls.Add(this.C4GradePoint);
            this.Controls.Add(this.C3GradePoint);
            this.Controls.Add(this.C1GradePoint);
            this.Controls.Add(this.C2GradePoint);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.C8Grade);
            this.Controls.Add(this.C7Grade);
            this.Controls.Add(this.C6Grade);
            this.Controls.Add(this.C5Grade);
            this.Controls.Add(this.C4Grade);
            this.Controls.Add(this.C3Grade);
            this.Controls.Add(this.C2Grade);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.C1Grade);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.C1CreditHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C2CreditHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3CreditHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C4CreditHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C5CreditHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6CreditHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C7CreditHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8CreditHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox C1Grade;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox C2Grade;
        private System.Windows.Forms.ComboBox C3Grade;
        private System.Windows.Forms.ComboBox C4Grade;
        private System.Windows.Forms.ComboBox C5Grade;
        private System.Windows.Forms.ComboBox C6Grade;
        private System.Windows.Forms.ComboBox C7Grade;
        private System.Windows.Forms.ComboBox C8Grade;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label C2GradePoint;
        private System.Windows.Forms.Label C1GradePoint;
        private System.Windows.Forms.Label C3GradePoint;
        private System.Windows.Forms.Label C4GradePoint;
        private System.Windows.Forms.Label C5GradePoint;
        private System.Windows.Forms.Label C7GradePoint;
        private System.Windows.Forms.Label C6GradePoint;
        private System.Windows.Forms.Label C8GradePoint;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.NumericUpDown C1CreditHours;
        private System.Windows.Forms.NumericUpDown C2CreditHours;
        private System.Windows.Forms.NumericUpDown C3CreditHours;
        private System.Windows.Forms.NumericUpDown C4CreditHours;
        private System.Windows.Forms.NumericUpDown C5CreditHours;
        private System.Windows.Forms.NumericUpDown C6CreditHours;
        private System.Windows.Forms.NumericUpDown C7CreditHours;
        private System.Windows.Forms.NumericUpDown C8CreditHours;
        private System.Windows.Forms.Label GPAlbl;
        private System.Windows.Forms.Label GPAValue;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

