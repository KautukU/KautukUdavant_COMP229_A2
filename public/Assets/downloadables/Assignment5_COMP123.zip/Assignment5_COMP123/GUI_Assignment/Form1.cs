﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Assignment
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            splashForm form = new splashForm();
            form.ShowDialog();
        }
        private void btnCal_Click(object sender, EventArgs e)
        {
            DoOperation();
        }

        public void DoOperation()
        {
            double h1, h2, h3, h4, h5, h6, h7, h8;
            double g1, g2, g3, g4, g5, g6, g7, g8;
            double total1, total2, total3, total4, total5, total6, total7, total8;
            double totalGPA;

            h1 = (double)C1CreditHours.Value;
            h2 = (double)C2CreditHours.Value;
            h3 = (double)C3CreditHours.Value;
            h4 = (double)C4CreditHours.Value;
            h5 = (double)C5CreditHours.Value;
            h6 = (double)C6CreditHours.Value;
            h7 = (double)C7CreditHours.Value;
            h8 = (double)C8CreditHours.Value;

            g1 = CheckGrades(C1Grade);
            g2 = CheckGrades(C2Grade);
            g3 = CheckGrades(C3Grade);
            g4 = CheckGrades(C4Grade);
            g5 = CheckGrades(C5Grade);
            g6 = CheckGrades(C6Grade);
            g7 = CheckGrades(C7Grade);
            g8 = CheckGrades(C8Grade);

            total1 = g1 * h1;
            total2 = g2 * h2;
            total3 = g3 * h3;
            total4 = g4 * h4;
            total5 = g5 * h5;
            total6 = g6 * h6;
            total7 = g7 * h7;
            total8 = g8 * h8;

            totalGPA = (total1 + total2 + total3 + total4 + total5 + total6 + total7 + total8) / (h1 + h2 + h3 + h4 + h5 + h6 + h7 + h8);

            C1GradePoint.Text = total1.ToString();
            C1GradePoint.Visible = true;

            C2GradePoint.Text = total2.ToString();
            C2GradePoint.Visible = true;
            
            C3GradePoint.Text = total3.ToString();
            C3GradePoint.Visible = true; 
            
            C4GradePoint.Text = total4.ToString();
            C4GradePoint.Visible = true; 
            
            C5GradePoint.Text = total5.ToString();
            C5GradePoint.Visible = true; 
            
            C6GradePoint.Text = total6.ToString();
            C6GradePoint.Visible = true; 
            
            C7GradePoint.Text = total7.ToString();
            C7GradePoint.Visible = true; 
            
            C8GradePoint.Visible = true;
            C8GradePoint.Text = total8.ToString();
            
            GPAlbl.Visible = true;
            
            GPAValue.Visible = true;
            GPAValue.Text = (Math.Round(Convert.ToDecimal(totalGPA), 2)).ToString();

        }

        public double CheckGrades(ComboBox Grade)
        {
            double gradepoint;

            if (Grade.Text == "A")
                gradepoint = 4.0;
            else if (Grade.Text == "A-")
                gradepoint = 3.70;
            else if (Grade.Text == "B+")
                gradepoint = 3.33;
            else if (Grade.Text == "B")
                gradepoint = 3.00;
            else if (Grade.Text == "B-")
                gradepoint = 2.70;
            else if (Grade.Text == "C+")
                gradepoint = 2.30;
            else if (Grade.Text == "C")
                gradepoint = 2.00;
            else if (Grade.Text == "C-")
                gradepoint = 1.70;
            else if (Grade.Text == "D+")
                gradepoint = 1.30;
            else if (Grade.Text == "D")
                gradepoint = 1.00;
            else if (Grade.Text == "D-")
                gradepoint = 0.70;
            else
                gradepoint = 0;

            return gradepoint;
        }
    }
}
